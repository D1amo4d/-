package com.example.adiletrecyclerview.model

data class Fio(
    val imgPoster:String?=null,
    val title:String?=null,
    val description:String?=null,
)
